package com.hbgcjsxy.chainexplorer;

import org.json.JSONObject;
import org.junit.Test;
import org.xutils.http.RequestParams;

import static org.junit.Assert.*;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import java.util.HashMap;
import java.util.Map;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
//        System.out.println(GetBlockTransactionList());
    }

}