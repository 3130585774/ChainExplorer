<h1 align="center">区块链浏览器 👋</h1>
<p>
  <img alt="Version" src="https://img.shields.io/badge/version-1.0.0-blue.svg?cacheSeconds=2592000" />
</p>

> 交易哈希查询详细信息  
> 支持主流公链

### JDK版本 11.0.15

***

## 作者

👤 **Thy**  
👤 **Spf**  
👤 **Ssc**

**🏫河北工程技术学院**
***
<p>
<img alt="预览" src = "./doc/预览.png" />
</p>

***

## Show your support

Give a ⭐️ if this project helped you!
***